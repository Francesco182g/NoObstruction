package com.example.francesco.noobstruction;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
/**
 *
 * NO OBSTRUCTION
 * Creata da Francesco Garofalo copy 2017
 * Versione 0.9 Update 23/01/2017
 *
 * Progettata da Francesco Garofalo, Leopoldo Buono, Giovanni Criscuolo, Giacomo Cocozziello
 */

/**
 * NO OBSTRUCTION
 * @author Francesco Garofalo
 */
public class MainActivity extends AppCompatActivity
        implements OnMapReadyCallback,
        GoogleMap.OnMyLocationButtonClickListener,
        ActivityCompat.OnRequestPermissionsResultCallback {

    // FUNZIONALITA PER LA MAPPA
    private boolean mPermissionDenied = false;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private GoogleMap mMap;
    //END

    /**
     * MARKERS:
     * Avellino
     */
    private static final LatLng PIAZZAMACELLO = new LatLng(40.9173528,14.7901742);
    private static final LatLng HOTELDELAVILLE = new LatLng(40.9169086, 14.7760247);
    private static final LatLng STADIOPARTENIO = new LatLng(40.9265465, 14.7917252);
    private static final LatLng FISCIANOTERMINAL = new LatLng(40.7739506,14.7933034);
    private static final LatLng PEDANAUNO = new LatLng(40.775155,14.7894767);
    private static final LatLng MUSEOAV = new LatLng(40.9153756,14.7876033);

    private Marker mPiazzaMacello;
    private Marker mHotelDelaVille;
    private Marker mStadioPartenio;
    private Marker mTerminalUnisa;
    private Marker mPedanaUnisa1;
    private Marker mMuseoAv;

    /**
     * Elementi Grafici dell'applicazione
     */
    private Button recenti;
    private Button scopri;
    private Button vicini;
    private ImageView cerca;
    private EditText cercapunto;
    private String address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        /*
        LOCALIZZAZIONE AUTO E MANUALE
         */
        /**
        Load Map (Problema di rendering)
         */
        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        Button recenti = (Button) findViewById(R.id.recenti);
        Button scopri = (Button) findViewById(R.id.scopri);
        Button vicini = (Button) findViewById(R.id.vicini);
        ImageView cerca = (ImageView) findViewById(R.id.cerca);
        final EditText cercapunto = (EditText) findViewById(R.id.cercapunto);

        recenti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Recenti.class);
                startActivity(i);
            }
        });

        scopri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Scopri.class);
                startActivity(i);
            }
        });

        vicini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Vicini.class);
                startActivity(i);
            }
        });

        cerca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                address = cercapunto.getText().toString();

                if (address != null) {
                    address = address.replace(' ', '+');
                    Intent geoIntent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + address));
                    startActivity(geoIntent);
                } else {

                    Toast toast = Toast.makeText(getApplicationContext(), "Campo ricerca vuoto", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;

        mMap.setOnMyLocationButtonClickListener(this);
        enableMyLocation();

        /**
         * MARKER AVELLINO & FISCIANO
         */
        // Add some markers to the map, and add a data object to each marker.
        mPiazzaMacello = mMap.addMarker(new MarkerOptions()
                .position(PIAZZAMACELLO)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.bus))
                .title("Pullman con pedana, Piazza Macello"));
        mPiazzaMacello.setTag(0);

        mHotelDelaVille = mMap.addMarker(new MarkerOptions()
                .position(HOTELDELAVILLE)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.hotel))
                .title("Hotel Dela Ville, Via Palatucci"));
        mHotelDelaVille.setTag(0);

        mStadioPartenio = mMap.addMarker(new MarkerOptions()
                .position(STADIOPARTENIO)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.stadio))
                .title("Stadio Partenio/Lombardi, Via Michele Capozzi"));
        mStadioPartenio.setTag(0);

        mTerminalUnisa = mMap.addMarker(new MarkerOptions()
                .position(FISCIANOTERMINAL)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.bus))
                .title("Terminal Fisciano, Via Giovanni Paolo II"));
        mTerminalUnisa.setTag(0);

        mMuseoAv = mMap.addMarker(new MarkerOptions()
                .position(MUSEOAV)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.accessibilemuseo))
                .title("MUSEO IRPINO, Via Giuseppe Verdi"));
        mMuseoAv.setTag(0);

        mPedanaUnisa1 = mMap.addMarker(new MarkerOptions()
                .position(PEDANAUNO)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.accessibile))
                .title("Pedana, Unisa Informatica (F1 & F2"));
        mPedanaUnisa1.setTag(0);

    }

    /**
     *   LOCALIZZAZIONE AUTOMATICA
     */
    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        } else if (mMap != null) {
            // Access to the location has been granted to the app.
            mMap.setMyLocationEnabled(true);
        }
    }

    @Override
    public boolean onMyLocationButtonClick() {
        Toast.makeText(this, "Posizione Attuale", Toast.LENGTH_SHORT).show();
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).
        return false;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode != LOCATION_PERMISSION_REQUEST_CODE) {
            return;
        }

        if (PermissionUtils.isPermissionGranted(permissions, grantResults,
                Manifest.permission.ACCESS_FINE_LOCATION)) {
            // Enable the my location layer if the permission has been granted.
            enableMyLocation();
        } else {
            // Display the missing permission error dialog when the fragments resume.
            mPermissionDenied = true;
        }
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        if (mPermissionDenied) {
            // Permission was not granted, display error dialog.
            showMissingPermissionError();
            mPermissionDenied = false;
        }
    }

    /**
     * Displays a dialog with error message explaining that the location permission is missing.
     */
    private void showMissingPermissionError() {
        PermissionUtils.PermissionDeniedDialog
                .newInstance(true).show(getSupportFragmentManager(), "dialog");
    }

    /**
     *
     * NO OBSTRUCTION
     * Creata da Francesco Garofalo copy 2017
     * Versione 0.9 Update 23/01/2017
     *
     * Progettata da Francesco Garofalo, Leopoldo Buono, Giovanni Criscuolo, Giacomo Cocozziello
    */
}
